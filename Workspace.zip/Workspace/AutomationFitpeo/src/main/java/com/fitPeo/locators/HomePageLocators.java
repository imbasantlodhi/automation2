package com.fitPeo.locators;
import javax.swing.text.html.parser.Element;

import org.openqa.selenium.WebElement;

import Chrome.setup.browserSetup;

public class HomePageLocators {
	//public static Element REVENUE_CAL = new Element("",Element.XPATH);
	//WebElement revenueCalculators driver.findElement(By.xpath(""));
	//revenueCalulators.click();
	
	

}
