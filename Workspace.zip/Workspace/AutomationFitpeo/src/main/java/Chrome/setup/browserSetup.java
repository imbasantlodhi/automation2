package Chrome.setup;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class browserSetup {
	public static void main(String[]args) throws InterruptedException {
		
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.fitpeo.com/");
		Thread.sleep(5000);
		System.out.println("page title is" + driver.getTitle());
		Thread.sleep(5000);
	
		WebElement revenueCalculators= driver.findElement(By.xpath("//div[text()='Revenue Calculator']"));
		revenueCalculators.click();
		//revenueCalculators.wait(1000);
		Thread.sleep(1000);

        WebElement slider = driver.findElement(By.xpath("//html/body/div[2]/div[1]/div[1]/div[2]/div/div/span[1]"));
        
        // Get the current width of the slider to calculate the pixel offset
        Dimension sliderSize = slider.getSize();
        int sliderWidth = sliderSize.width;
        
        // Set the maximum slider value (2000) and target value (820)
        int maxValue = 2000;
        int targetValue = 820;
        
        // Calculate the pixel position where the slider needs to be set
        int position = (targetValue * sliderWidth) / maxValue;
        
        // Get the current position of the slider (X-coordinate)
        int currentSliderX = slider.getLocation().getX();
        
        // Calculate the offset needed to move the slider to the target position
        int offset = position - currentSliderX;
        
        // Use Actions class to perform a drag-and-drop action on the slider
        Thread.sleep(3000);
  //      System.out.println("12");
        Actions actions = new Actions(driver);
        actions.clickAndHold(slider).moveByOffset(offset, 0).release().perform();
        Thread.sleep(3000);

        
        // Optionally, verify the value of the text field (if there's a text field that updates with the slider)
        WebElement textField = driver.findElement(By.id(":r0:")); // Replace with the actual XPath or ID of the text field
        String textFieldValue = textField.getAttribute("value");
        System.out.println("12");
        // Check if the value is 820
        if (textFieldValue.equals("0")) {
            System.out.println("Slider value successfully set to 820.");
        } else {
            System.out.println("Failed to set slider value to 820. Current value: " + textFieldValue);
        }
		
	
		Thread.sleep(1000);
		//selectDefineValue.sendKeys("1");
		Thread.sleep(2000);

		textField.clear();        // Clears any existing value
		textField.sendKeys("560");
		String textFieldValue1 = textField.getAttribute("value");
		if (textFieldValue1.equals("0560")) {
		    System.out.println("Text field value successfully set to 560.");
		} else {
		    System.out.println("Failed to set text field value to 560. Current value: " + textFieldValue1);
		}
		


        // Checkbox 1: Located by XPath
        WebElement checkbox1 = driver.findElement(By.xpath("//html/body/div[2]/div[1]/div[2]/div[2]/label/span[1]/input"));
        if (!checkbox1.isSelected()) {
            checkbox1.click(); // Click to select if not already selected
        }
        Thread.sleep(2000);
        // Checkbox 2: Located by XPath
        WebElement checkbox2 = driver.findElement(By.xpath("//html/body/div[2]/div[1]/div[2]/div[1]/label/span[1]/input"));
        if (!checkbox2.isSelected()) {
            checkbox2.click(); // Click to select if not already selected
        }
        Thread.sleep(2000);
        // Checkbox 3: Located by XPath
        WebElement checkbox3 = driver.findElement(By.xpath("/html/body/div[2]/div[1]/div[2]/div[3]/label/span[1]/input"));
        if (!checkbox3.isSelected()) {
            checkbox3.click(); // Click to select if not already selected
        }
        Thread.sleep(2000);
        // Checkbox 4: Located by XPath
        WebElement checkbox4 = driver.findElement(By.xpath("/html/body/div[2]/div[1]/div[2]/div[8]/label/span[1]/input"));
        if (!checkbox4.isSelected()) {
            checkbox4.click(); // Click to select if not already selected
        }

        // Validate if the checkboxes are selected
        validateCheckboxSelection(checkbox1);
        validateCheckboxSelection(checkbox2);
        validateCheckboxSelection(checkbox3);
        validateCheckboxSelection(checkbox4);
        // Wait for the header to be updated
     //   WebDriverWait wait = new WebDriverWait(driver,10);
       // Thread.sleep(2000);
        WebElement header = driver.findElement(By.xpath("//html/body/div[2]/div[1]/header"));
       header.isDisplayed();

        
       WebElement header1 = driver.findElement(By.xpath("/html/body/div[2]/div[1]/header/div/p[4]/p"));
     //   WebElement checkbox2 = driver.findElement(By.xpath("//html/body/div[2]/div[1]/div[2]/div[1]/label/span[1]/input"));
        
        // Get the value of the header
        String headerText = header1.getText().trim();

        // Verify that the header displays the expected value
        if (headerText.equals("$75600")) {
            System.out.println("Header value is correct: $110700" );
        } else {
            System.out.println("Header value is incorrect. Current value: " + headerText);
        }

        // Close the driver
       driver.quit();
    }


    public static void validateCheckboxSelection(WebElement checkbox) {
        if (checkbox.isSelected()) {
            System.out.println("Checkbox is selected.");
        } else {
            System.out.println("Checkbox is NOT selected.");
        }
    
		
		
		
		
		
		
		
		
		
		
		
	//driver.quit();	
		
		
	}
	
//	@Test(alwaysRun=true)
//	public void closeDriver() {
//		driver.get().quit();
//
//}
}

