package Chrome.setup;

public @interface Test {

	boolean alwaysRun();



}
